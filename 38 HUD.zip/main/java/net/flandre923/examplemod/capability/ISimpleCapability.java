package net.flandre923.examplemod.capability;

import net.minecraft.core.BlockPos;

public interface ISimpleCapability {
    public void getString(BlockPos pos);
}
