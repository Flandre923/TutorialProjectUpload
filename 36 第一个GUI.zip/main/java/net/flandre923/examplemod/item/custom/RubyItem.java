package net.flandre923.examplemod.item.custom;

import net.minecraft.world.item.Item;

public class RubyItem extends Item {
    public RubyItem(Properties pProperties) {
        super(pProperties);
    }
    
}
