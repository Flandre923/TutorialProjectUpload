package net.flandre923.examplemod.item.custom;

import net.minecraft.world.item.Item;

public class MagicIngot extends Item {
    public MagicIngot() {
        super(new Properties());
    }

}
