package net.flandre923.examplemod.item.custom;

import net.minecraft.world.item.Item;

public class RubyWand extends Item {
    public RubyWand(){
        super(new Properties().stacksTo(1));
    }
}
